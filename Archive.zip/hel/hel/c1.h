//
//  c1.h
//  hel
//
//  Created by dz2701 on 6/19/20.
//  Copyright © 2020 dz2701. All rights reserved.
//

Define Class1

