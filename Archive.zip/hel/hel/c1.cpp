//
//  c1.cpp
//  hel
//
//  Created by dz2701 on 6/19/20.
//  Copyright © 2020 dz2701. All rights reserved.
//

#include"c1.h"

Implementation of Class1;
