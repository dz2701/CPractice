//
//  main.cpp
//  1008 AB
//
//  Created by dz2701 on 6/13/20.
//  Copyright © 2020 dz2701. All rights reserved.
//
#include <bits/stdc++.h>
int main(){double a,b;std::cin>>a>>b;std::cout<<a/b;}
