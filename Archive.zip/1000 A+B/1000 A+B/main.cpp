//
//  main.cpp
//  1000
//
//  Created by Shin Lee on 11/14/17.
//  Copyright © 2017 Shin Lee. All rights reserved.
//

#include <stdio.h>

int main()
{
    int a, b;
    scanf("%d %d",&a,&b);
    printf("%d",a+b);
    return 0;
}
