//
//  hello-world-gtk.c
//  gtk_prac
//
//  Created by dz2701 on 8/6/20.
//  Copyright © 2020 dz2701. All rights reserved.
//

#
